<% if false %>
<script type="text/javascript">
window.onload = function() {
   window.open('/backgroundmusic','Background Music',' menubar=0, resizable=0,dependent=0,status=0,width=300,height=200,left=10,top=10')}
</script>
<% end %>