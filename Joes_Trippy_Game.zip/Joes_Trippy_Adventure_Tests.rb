require_relative 'trippy_game_functions.rb'
require "minitest/autorun"

class Main_test < Minitest::Test

def test_for_yes
assert_equal(chill_with_dave,L(go_to_club))
end



end
