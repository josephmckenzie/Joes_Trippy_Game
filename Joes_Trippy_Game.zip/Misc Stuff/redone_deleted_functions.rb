# def lose_buzz(come_down)

		# puts "You buzz has wore off by  #{come_down} hits "
			# @acid_amount -= come_down
		# puts "This is how much your have left in your systme #{@acid_amount}"
# end
		
# def add_to_stash
	
# @name = $stdin.gets.chomp.upcase
	# @stash = [] unless @stash
	# @stash << @name
		# puts "You just added #{@name} to your stash"
		# puts "You now have the following items in your stash #{@stash}" 
# end


# def del_stash
# @inven= $stdin.gets.chomp
	# if @stash.include?(@inven)
	   # @stash.delete(@inven)
		# puts "You used #{@inven} from your stash"
	# else 
		# puts "That Item is not in your stash!!"
	# end
	# puts "You now have the following items left in your stash #{@stash}"
# end
