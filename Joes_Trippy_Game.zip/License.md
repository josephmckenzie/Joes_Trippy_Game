License Agreement for Joe's Trippy Game © 04/20/4242   go ahead and if you want to use any part
of this game for your own personal use you can but however if you are using any part of this game 
for commerical uses then you must contact me and ask if I care which I probabaly won't but you still 
have to ask me. All the sounds i used were gathered various places off of the internet so if I used 
your sound and I wasn't allowed sorry and contact me and I will remedy it. All the sites I got these
sounds from said use however you want to though but you never know.   

Contact me Via:

Email: joestrippygame@gmail.com
Facebook: www.facebook.com/josephmckenziepcrepair
My cell: Yeah right your not getting that email me or facebook me and we will do what we need to do.

