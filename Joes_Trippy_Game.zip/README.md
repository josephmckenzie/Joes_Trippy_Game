Welcome to Joe's Magical Trippy Adventure Game.

To start the Online Version First Run Start_Games_online.rb and then Go to localhost:4567/startgames

I first started learning how to program using the Ruby Language about 2 months ago and am loving it, This is one of
my first attempts at making my own game. This game will be in the style of a choose your own adventure game.
My game will include many adult situations including but not limited to drugs and mild adult language. 
You should probably be over 18 to play it seeing what the subject matter pertains to, but seeing how there is really
no way to prove how old you are nowadays It don't really matter to me but if you are easily offended don't play 
Because I really don't want to hear anyone complaining that they were offended by it. However if you are a down to
earth type of person that enjoys a Crazy type of game then Enjoy...

If you play this game and enjoy it and have ideas for another game that you would like me to make you can contact me

Email: joestrippygame@gmail.com
FaceBook: https://www.facebook.com/JosephMckenziepcrepair 
