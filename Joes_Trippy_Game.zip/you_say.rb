class You_say

	def yeah_lets_go
		"\"Yeah let's go man, but do you wanna smoke some before we leave??\""
	end
	
	def ok_to_acid
		"You Say \" Ok and close your eyes and stick out your tounge\""
	end
	
	def gee_idk
		 "You Say \" Gee I don't know man why what is it ?......\""
	end
	
	def did_you_see_that
		"Hey man you seeing what I'm seeing?"
	end
	
	def i_saw_something
		"No man I know I saw something, you wanna go check it out with me?" 
	end
	
	
	
	
	
	
end
