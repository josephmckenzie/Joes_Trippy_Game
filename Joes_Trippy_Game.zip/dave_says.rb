class Dave_says

	def whats_up(name)
		"\"Whats up  #{name} I'm Thinking about hitting the club up wanna go?\""
	end
	
	def watchin_tv
		"After watching a little TV Dave Says \"Lets go to the club man\""
	end
	
	def stick_out_tounge?(name)
		"Dave says to you... \"Hey #{name} close your eyes and stick out your tounge... \""
	end
	
	def if_you_need_to_know(name)
		"Dave says to you... \"Hey #{name} if you need to know than it wont be as fun..... \""
	end
	
	def still_wanna_know
		 "Do you still wanna know what it is ?"
	end
		
	def its_acid_man(name)
		 ["\"Man #{name} it's some blotter acid. I wanted it to be a surprise though man....\"","Do you want some or not #{name}?"].join("<br>")
	end
	
	def dont_want_to_know(name)
		["Man #{name} thats good I didnt wanna tell you what it was anyways man."," Do you want some of what I got then #{name}?"].join("<br>")
	end
	
	def nah_its_cool
		"Nah man It's Cool your just seeing shit its the acid man."
	end
	
	def wanna_play_pool(name)
		"Dave Says hey #{name} wanna play a round? "
	end
	
	
	
	
	
	
	
	
	
end

	