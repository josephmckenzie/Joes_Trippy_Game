class Misc_messages

	def not_done
		"Sorry This is the end for now, I am still programming this game."
	end


	def downloads
		"Here are my games I have available for download"
	end
		
end