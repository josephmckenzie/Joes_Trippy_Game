class Trippy_messages

	def knock(name)
		"One day #{name} is sitting around Smoking a bong when someone knocks on the door."
	end
	
	def answer
		"Do you get up and answer it?"
	end

	def its_dave(name)
		"Your in Luck #{name}, It's Your Good Buddy Dave."
	end

	def cops_at_door(name)
		"\"Fuck #{name} I'ts the cops $ they bust in and see the bong lying on the table\""
	end
	
	def arrested(name)
		 "\"Well damn man. That sucks for you #{name} They arrest you & take you to jail....\""
	end
	
	def dave_comes_in(name)
		"It doesn't really matter #{name}, cause Your Good Buddy Dave walks in on his own."
	end
	
	def go_to_club?(name)
		"\"Whats up  #{name} I'm Thinking about hitting the club up wanna go?\""
	end
	
	def smoke_first(name)
		"#{name} & Dave decide to smoke some bud first and watch a little tv....."
	end
	
	def chill_or_leave(name)
		"Hey #{name} & Dave do you guys wanna just chill at home or Leave for the club now?"
	end
	
	def leave_now(name)
		"#{name} & Dave roll a couple blunts real quick,and you leave for the club...."
	end
	
	def pull_up_to_club
		"You pull up to the club. Do you go in right away or go smoke a blunt in the woods first?"
	end
	
	def smoke_n_leave(name)
		"After Smoking a couple bongs, #{name} & Dave leave for the club...."
	end
	
	def pull_up_to_club(name)
		 "You pull up to the club."
	end
	
	def club_or_smoke?
		"Do you go in right away or go for a walk in the woods first?"
	end
	
	def just_chill
		 "You guys decide to just chill out for a while......"
	end
		
	def stick_out_tounge(name)
		"Dave says to you... \"Hey #{name} close your eyes and stick out your tounge... \""
	end
	
	def stick_out_tounge?
		"Do you stick out your tounge?"
	end
	
	def places_acid_on_tounge
		"Dave places a tiny piece of paper Upon your tounge"
	end
	
	def dosed_now_leave?
		"Now that you have taken your dose Do you wanna hang out here or Leave for the club "
	end
	
	def have_to_trip(name)
		 ["\" Sorry #{name} you need to be tripping in order to play this game....\""," Will you take some #{name} or do you wish to quit now and go play something else?"].join("<br>")
	end
	
	def just_chill()
		"You guys decide to just chill and enjoy your buzzes for a while"
	end
		
	def see_something_crazy(name)
		"A little while later #{name} is really starting to trip when you notice something really crazy looking ...."
	end
	
	def dose_and_leave(name)
		"After having taken a thier doses #{name} & Dave get ready for the club and leave...."
	end
	
	def take_car_or_walk
		"Do you Take the car or Walk"
	end
	
	def take_car(name)
		"#{name} & Dave take the car and its not long before they are really tripping hard."
	end
	
	def greedy_shots()
		"Well you decide to be a greedy little ass and not pass out any of the shots."
	
	end
	
	def need_all_that()
		"Wow man you really think you need all them to yourselves?"
	end

	def jerry_is_a_dick()
		"everyone except Jerry cause he's a dick."
	end

	def round_of_shots(name)
		"#{name} & Dave pass out a few of the shots around"
	end
	
	def round_of_beers(name)
		"#{name} & Dave Buy a round of beers for everyone sitting at the bar,"
	end
	
	def greedy_beer(name)
		"#{name} decides not be cool and buy a round"
	end
	
	def pull_over_and_walk()
		"Will you pull over and walk the rest of the way or Do you continue to drive the rest of the way?"
	end
	
	def start_trippin_in_car(name)
		"#{name} & Dave take the car and its not long before they start tripping."
	end
	
	def take_shortcut()
		"Do you take the shortcut through the woods?"
	end
	
	def start_out_walking(name)
		"#{name} & Dave start out walking and before no time the reach a shortcut through the woods "
	end
	
	def random_says()
		"Because the random function says so"
	end
	
	
	
end


	
	
	